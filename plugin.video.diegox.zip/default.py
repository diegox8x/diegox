# FILE: default.py CONTENT
# This file is intentionally left blank.